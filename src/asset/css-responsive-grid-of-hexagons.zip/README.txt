A Pen created at CodePen.io. You can find this one at http://codepen.io/web-tiki/pen/HhCyd.

 Grid of regular hexagons using CSS with a hover effect to show text. This grid is responsive. 

You can find more info about this responsive grid of hexagons here : http://stackoverflow.com/questions/26114920/responsive-grid-of-hexagons/26116497#26116497

You can alos find more grids with other layouts and features in this codepen collection :  http://codepen.io/collection/npgxpm/
